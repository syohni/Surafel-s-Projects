/**
 * 
 */
/**
 * 
 */
module SalemuLab3Assignment {
	requires junit;
}