package lab6;

/**
 * The purpose of this class is to model a television
 * Surafel Yohannes
 * December 2025
 */

public class Television
{
    // Named constants (cannot change after creation)
    private final String MANUFACTURER;   // Holds the brand name
    private final int SCREEN_SIZE;       // Holds the screen size

    // Remaining fields (can change)
    private boolean powerOn;   // true if power is on, false if off
    private int channel;       // current channel
    private int volume;        // current volume level

    /**
     * Constructor that initializes the brand and screen size
     * Power is off, volume is set to 20, channel is set to 2
     */
    public Television(String brand, int size)
    {
        MANUFACTURER = brand;
        SCREEN_SIZE = size;
        powerOn = false;
        volume = 20;
        channel = 2;
    }

    /** Returns the current volume */
    public int getVolume()
    {
        return volume;
    }

    /** Returns the current channel */
    public int getChannel()
    {
        return channel;
    }

    /** Returns the manufacturer name */
    public String getManufacturer()
    {
        return MANUFACTURER;
    }

    /** Returns the screen size */
    public int getScreenSize()
    {
        return SCREEN_SIZE;
    }

    /** Sets the channel to the given station */
    public void setChannel(int station)
    {
        channel = station;
    }

    /** Toggles the power on and off */
    public void power()
    {
        powerOn = !powerOn;
    }

    /** Increases volume by 1 */
    public void increaseVolume()
    {
        volume++;
    }

    /** Decreases volume by 1 */
    public void decreaseVolume()
    {
        volume--;
    }
}

