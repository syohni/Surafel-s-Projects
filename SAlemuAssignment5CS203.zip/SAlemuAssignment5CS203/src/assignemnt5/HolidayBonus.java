package assignemnt5;

/**
 * Utility class to calculate holiday bonuses for stores in a district.
 * 
 * Bonuses are based on per-category (column) sales:
 * - Highest positive sales in a category: HIGH_BONUS
 * - Lowest positive sales in a category: LOW_BONUS
 * - All other positive sales in category: OTHER_BONUS
 * - Zero or negative sales: no bonus for that category
 * - If only one store has positive sales in a category: it gets only HIGH_BONUS
 */
public class HolidayBonus {

    // Constant bonus amounts
    private static final double HIGH_BONUS = 5000.0;
    private static final double LOW_BONUS  = 1000.0;
    private static final double OTHER_BONUS = 2000.0;

    /**
     * Calculates the holiday bonuses for each store.
     * 
     * @param data two-dimensional ragged array of store sales
     * @return a one-dimensional array of bonuses, one per store (row)
     */
    public static double[] calculateHolidayBonus(double[][] data) {
        double[] bonuses = new double[data.length];

        // Find the maximum number of columns across all rows
        int maxCols = 0;
        for (int r = 0; r < data.length; r++) {
            if (data[r].length > maxCols) {
                maxCols = data[r].length;
            }
        }

        // Process each column (category)
        for (int col = 0; col < maxCols; col++) {

            // Collect rows that have a positive value at this column
            java.util.ArrayList<Integer> validRows = new java.util.ArrayList<>();

            for (int row = 0; row < data.length; row++) {
                if (col < data[row].length) {          // column exists in this row
                    double value = data[row][col];
                    if (value > 0) {                   // only positive sales count
                        validRows.add(row);
                    }
                }
            }

            // No positive sales in this column
            if (validRows.size() == 0) {
                continue;
            }

            // Only one store sold something in this category → only high bonus
            if (validRows.size() == 1) {
                int onlyRow = validRows.get(0);
                bonuses[onlyRow] += HIGH_BONUS;
                continue;
            }

            // Find highest and lowest positive values for this column
            int highestRow = validRows.get(0);
            int lowestRow = validRows.get(0);

            for (int idx : validRows) {
                double value = data[idx][col];
                if (value > data[highestRow][col]) {
                    highestRow = idx;
                }
                if (value < data[lowestRow][col]) {
                    lowestRow = idx;
                }
            }

            // Assign bonuses for this column
            for (int idx : validRows) {
                if (idx == highestRow) {
                    bonuses[idx] += HIGH_BONUS;
                } else if (idx == lowestRow) {
                    bonuses[idx] += LOW_BONUS;
                } else {
                    bonuses[idx] += OTHER_BONUS;
                }
            }
        }

        return bonuses;
    }

    /**
     * Calculates the total of all holiday bonuses.
     * 
     * @param data two-dimensional ragged array of store sales
     * @return total of all bonuses
     */
    public static double calculateTotalHolidayBonus(double[][] data) {
        double[] bonuses = calculateHolidayBonus(data);
        double total = 0.0;
        for (double b : bonuses) {
            total += b;
        }
        return total;
    }
}

