package assignemnt5;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Student test cases for HolidayBonus.
 */
public class HolidayBonusTestStudent {

    @Test
    public void testCalculateHolidayBonusBasic() {
        double[][] dataSet1 = { { 1, 2, 3 }, { 4, 5 }, { 6, 7, 8 } };
        double[] result = HolidayBonus.calculateHolidayBonus(dataSet1);

        // These expected values match the GFA test
        assertEquals(3000.0, result[0], 0.001);
        assertEquals(4000.0, result[1], 0.001);
        assertEquals(15000.0, result[2], 0.001);
    }

    @Test
    public void testCalculateTotalHolidayBonusBasic() {
        double[][] dataSet1 = { { 1, 2, 3 }, { 4, 5 }, { 6, 7, 8 } };
        double total = HolidayBonus.calculateTotalHolidayBonus(dataSet1);
        assertEquals(22000.0, total, 0.001);
    }
}

