package assignemnt5;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Utility methods for a two-dimensional ragged array of doubles.
 * 
 * All methods are static and operate directly on a double[][].
 */
public class TwoDimRaggedArrayUtility {

    /**
     * Reads a file and returns a two-dimensional ragged array of doubles.
     * Each line in the file is a row; values are separated by spaces.
     * 
     * @param file the file to read
     * @return a two-dimensional ragged array of doubles
     * @throws FileNotFoundException if the file cannot be opened
     */
    public static double[][] readFile(File file) throws FileNotFoundException {
        Scanner input = new Scanner(file);
        ArrayList<double[]> rows = new ArrayList<>();

        while (input.hasNextLine()) {
            String line = input.nextLine().trim();
            if (line.length() == 0) {
                continue; // skip empty lines
            }
            String[] parts = line.split("\\s+");
            double[] row = new double[parts.length];
            for (int i = 0; i < parts.length; i++) {
                row[i] = Double.parseDouble(parts[i]);
            }
            rows.add(row);
        }
        input.close();

        double[][] data = new double[rows.size()][];
        for (int i = 0; i < rows.size(); i++) {
            data[i] = rows.get(i);
        }
        return data;
    }

    /**
     * Writes a ragged array to a file.
     * Each row on its own line and each double separated by a space.
     * 
     * @param data the ragged array of doubles
     * @param outputFile the file to write to
     * @throws FileNotFoundException if the file cannot be written
     */
    public static void writeToFile(double[][] data, File outputFile) throws FileNotFoundException {
        PrintWriter out = new PrintWriter(outputFile);
        for (int r = 0; r < data.length; r++) {
            for (int c = 0; c < data[r].length; c++) {
                out.print(data[r][c]);
                if (c < data[r].length - 1) {
                    out.print(" ");
                }
            }
            out.println();
        }
        out.close();
    }

    /**
     * Returns the total of all elements in the array.
     */
    public static double getTotal(double[][] data) {
        double total = 0.0;
        for (int r = 0; r < data.length; r++) {
            for (int c = 0; c < data[r].length; c++) {
                total += data[r][c];
            }
        }
        return total;
    }

    /**
     * Returns the average of all elements in the array.
     */
    public static double getAverage(double[][] data) {
        double total = 0.0;
        int count = 0;
        for (int r = 0; r < data.length; r++) {
            for (int c = 0; c < data[r].length; c++) {
                total += data[r][c];
                count++;
            }
        }
        if (count == 0) {
            return 0.0;
        }
        return total / count;
    }

    /**
     * Returns the total of the elements in the specified row.
     * row index 0 is the first row.
     */
    public static double getRowTotal(double[][] data, int row) {
        double total = 0.0;
        for (int c = 0; c < data[row].length; c++) {
            total += data[row][c];
        }
        return total;
    }

    /**
     * Returns the total of the elements in the specified column.
     * If a row doesn't have that column, it is skipped.
     */
    public static double getColumnTotal(double[][] data, int col) {
        double total = 0.0;
        for (int r = 0; r < data.length; r++) {
            if (col < data[r].length) {
                total += data[r][col];
            }
        }
        return total;
    }

    /**
     * Returns the highest value in the specified row.
     */
    public static double getHighestInRow(double[][] data, int row) {
        double max = data[row][0];
        for (int c = 1; c < data[row].length; c++) {
            if (data[row][c] > max) {
                max = data[row][c];
            }
        }
        return max;
    }

    /**
     * Returns the index of the highest value in the specified row.
     */
    public static int getHighestInRowIndex(double[][] data, int row) {
        int maxIndex = 0;
        for (int c = 1; c < data[row].length; c++) {
            if (data[row][c] > data[row][maxIndex]) {
                maxIndex = c;
            }
        }
        return maxIndex;
    }

    /**
     * Returns the lowest value in the specified row.
     */
    public static double getLowestInRow(double[][] data, int row) {
        double min = data[row][0];
        for (int c = 1; c < data[row].length; c++) {
            if (data[row][c] < min) {
                min = data[row][c];
            }
        }
        return min;
    }

    /**
     * Returns the index of the lowest value in the specified row.
     */
    public static int getLowestInRowIndex(double[][] data, int row) {
        int minIndex = 0;
        for (int c = 1; c < data[row].length; c++) {
            if (data[row][c] < data[row][minIndex]) {
                minIndex = c;
            }
        }
        return minIndex;
    }

    /**
     * Returns the highest value in the specified column.
     * Only rows that contain that column participate.
     */
    public static double getHighestInColumn(double[][] data, int col) {
        boolean found = false;
        double max = 0.0;
        for (int r = 0; r < data.length; r++) {
            if (col < data[r].length) {
                if (!found) {
                    max = data[r][col];
                    found = true;
                } else if (data[r][col] > max) {
                    max = data[r][col];
                }
            }
        }
        return max;
    }

    /**
     * Returns the index of the row with the highest value in the specified column.
     */
    public static int getHighestInColumnIndex(double[][] data, int col) {
        boolean found = false;
        double max = 0.0;
        int index = -1;
        for (int r = 0; r < data.length; r++) {
            if (col < data[r].length) {
                if (!found) {
                    max = data[r][col];
                    index = r;
                    found = true;
                } else if (data[r][col] > max) {
                    max = data[r][col];
                    index = r;
                }
            }
        }
        return index;
    }

    /**
     * Returns the lowest value in the specified column.
     * Only rows that contain that column participate.
     */
    public static double getLowestInColumn(double[][] data, int col) {
        boolean found = false;
        double min = 0.0;
        for (int r = 0; r < data.length; r++) {
            if (col < data[r].length) {
                if (!found) {
                    min = data[r][col];
                    found = true;
                } else if (data[r][col] < min) {
                    min = data[r][col];
                }
            }
        }
        return min;
    }

    /**
     * Returns the index of the row with the lowest value in the specified column.
     */
    public static int getLowestInColumnIndex(double[][] data, int col) {
        boolean found = false;
        double min = 0.0;
        int index = -1;
        for (int r = 0; r < data.length; r++) {
            if (col < data[r].length) {
                if (!found) {
                    min = data[r][col];
                    index = r;
                    found = true;
                } else if (data[r][col] < min) {
                    min = data[r][col];
                    index = r;
                }
            }
        }
        return index;
    }

    /**
     * Returns the highest value in the entire array.
     */
    public static double getHighestInArray(double[][] data) {
        double max = data[0][0];
        for (int r = 0; r < data.length; r++) {
            for (int c = 0; c < data[r].length; c++) {
                if (data[r][c] > max) {
                    max = data[r][c];
                }
            }
        }
        return max;
    }

    /**
     * Returns the lowest value in the entire array.
     */
    public static double getLowestInArray(double[][] data) {
        double min = data[0][0];
        for (int r = 0; r < data.length; r++) {
            for (int c = 0; c < data[r].length; c++) {
                if (data[r][c] < min) {
                    min = data[r][c];
                }
            }
        }
        return min;
    }
}

