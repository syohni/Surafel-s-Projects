package assignemnt5;

import static org.junit.Assert.*;
import java.io.File;
import java.io.FileNotFoundException;
import org.junit.Test;

/**
 * Student test cases for TwoDimRaggedArrayUtility.
 */
public class TwoDimRaggedArrayUtilityTestStudent {

    @Test
    public void testGetTotal() {
        double[][] data = { {1,2,3}, {4,5}, {6} };
        assertEquals(21.0, TwoDimRaggedArrayUtility.getTotal(data), 0.001);
    }

    @Test
    public void testGetAverage() {
        double[][] data = { {2,2}, {2} }; // total = 6, count = 3
        assertEquals(2.0, TwoDimRaggedArrayUtility.getAverage(data), 0.001);
    }

    @Test
    public void testGetRowTotal() {
        double[][] data = { {1,2,3}, {4,5}, {6} };
        assertEquals(9.0, TwoDimRaggedArrayUtility.getRowTotal(data, 1), 0.001);
    }

    @Test
    public void testGetColumnTotal() {
        double[][] data = { {1,2,3}, {4,5}, {6,7,8,9} };
        // column 1 → 2 + 5 + 7 = 14
        assertEquals(14.0, TwoDimRaggedArrayUtility.getColumnTotal(data, 1), 0.001);
    }

    @Test
    public void testGetHighestInRow() {
        double[][] data = { {3,10,6} };
        assertEquals(10.0, TwoDimRaggedArrayUtility.getHighestInRow(data, 0), 0.001);
    }

    @Test
    public void testGetHighestInRowIndex() {
        double[][] data = { {3,10,6} };
        assertEquals(1, TwoDimRaggedArrayUtility.getHighestInRowIndex(data, 0));
    }

    @Test
    public void testGetLowestInRow() {
        double[][] data = { {3,10,6} };
        assertEquals(3.0, TwoDimRaggedArrayUtility.getLowestInRow(data, 0), 0.001);
    }

    @Test
    public void testGetLowestInRowIndex() {
        double[][] data = { {3,10,6} };
        assertEquals(0, TwoDimRaggedArrayUtility.getLowestInRowIndex(data, 0));
    }

    @Test
    public void testGetHighestInColumn() {
        double[][] data = { {1}, {4}, {2} };
        assertEquals(4.0, TwoDimRaggedArrayUtility.getHighestInColumn(data, 0), 0.001);
    }

    @Test
    public void testGetHighestInColumnIndex() {
        double[][] data = { {1}, {4}, {2} };
        assertEquals(1, TwoDimRaggedArrayUtility.getHighestInColumnIndex(data, 0));
    }

    @Test
    public void testGetLowestInColumn() {
        double[][] data = { {5}, {4}, {6} };
        assertEquals(4.0, TwoDimRaggedArrayUtility.getLowestInColumn(data, 0), 0.001);
    }

    @Test
    public void testGetLowestInColumnIndex() {
        double[][] data = { {5}, {4}, {6} };
        assertEquals(1, TwoDimRaggedArrayUtility.getLowestInColumnIndex(data, 0));
    }

    @Test
    public void testGetHighestInArray() {
        double[][] data = { {1,50}, {-5,12} };
        assertEquals(50.0, TwoDimRaggedArrayUtility.getHighestInArray(data), 0.001);
    }

    @Test
    public void testGetLowestInArray() {
        double[][] data = { {1,50}, {-5,12} };
        assertEquals(-5.0, TwoDimRaggedArrayUtility.getLowestInArray(data), 0.001);
    }

    @Test
    public void testReadWriteFile() throws FileNotFoundException {
        double[][] data = { {1,2,3}, {4,5}, {6} };
        File f = new File("studentData.txt");
        TwoDimRaggedArrayUtility.writeToFile(data, f);

        double[][] read = TwoDimRaggedArrayUtility.readFile(f);

        assertEquals(3, read.length);
        assertEquals(3, read[0].length);
        assertEquals(2, read[1].length);
        assertEquals(1, read[2].length);

        f.delete(); // clean up
    }
}

