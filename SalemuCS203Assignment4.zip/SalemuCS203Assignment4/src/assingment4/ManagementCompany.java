package assingment4;

/*
 * Class: CMSC203
 * Description: Manages properties owned by a management company.
 */

public class ManagementCompany {
    public static final int MAX_PROPERTY = 5;
    public static final int MGMT_WIDTH = 10;
    public static final int MGMT_DEPTH = 10;

    private String name;
    private String taxID;
    private double mgmFee;
    private Property[] properties;
    private Plot plot;
    private int numberOfProperties;

    // Constructors
    public ManagementCompany(String name, String taxID, double mgmFee) {
        this.name = name;
        this.taxID = taxID;
        this.mgmFee = mgmFee;
        this.plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
        this.properties = new Property[MAX_PROPERTY];
        this.numberOfProperties = 0;
    }

    // Optional: Overloaded constructor accepting int mgmFee
    public ManagementCompany(String name, String taxID, int mgmFee) {
        this(name, taxID, (double) mgmFee);
    }

    // Getters
    public String getName() { return name; }
    public Plot getPlot() { return new Plot(plot); }
    public double getTotalRent() {
        double total = 0;
        for (int i = 0; i < numberOfProperties; i++)
            if (properties[i] != null)
                total += properties[i].getRentAmount();
        return total;
    }

    public int getPropertiesCount() {
        return numberOfProperties;
    }

    public boolean isPropertiesFull() {
        return numberOfProperties >= MAX_PROPERTY;
    }

    public boolean isManagementFeeValid() {
        return mgmFee >= 0 && mgmFee <= 100;
    }

    public int addProperty(Property property) {
        if (property == null) return -2;
        if (isPropertiesFull()) return -1;
        if (!plot.encompasses(property.getPlot())) return -3;
        for (int i = 0; i < numberOfProperties; i++) {
            if (properties[i] != null && properties[i].getPlot().overlaps(property.getPlot()))
                return -4;
        }
        properties[numberOfProperties] = new Property(property);
        return numberOfProperties++;
    }

    public Property getHighestRentPropperty() {
        if (numberOfProperties == 0) return null;
        Property max = properties[0];
        for (int i = 1; i < numberOfProperties; i++)
            if (properties[i].getRentAmount() > max.getRentAmount())
                max = properties[i];
        return new Property(max);
    }

    public void removeLastProperty() {
        if (numberOfProperties > 0)
            properties[--numberOfProperties] = null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("List of the properties for " + name + ", taxID: " + taxID + "\n");
        sb.append("______________________________________________________\n");
        for (int i = 0; i < numberOfProperties; i++) {
            sb.append(properties[i].toString()).append("\n");
        }
        sb.append("______________________________________________________\n");
        sb.append("\ntotal management Fee: ").append(getTotalRent() * mgmFee / 100);
        return sb.toString();
    }
}
