package assingment4;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class ManagementCompanyTestStudent {
    private ManagementCompany company;
    private Property p1, p2, p3;

    @Before
    public void setUp() {
        company = new ManagementCompany("TestCo", "12345", 10);
        p1 = new Property("Prop1", "City1", "Owner1", 1000.0, 0, 0, 2, 2);
        p2 = new Property("Prop2", "City2", "Owner2", 2000.0, 2, 2, 2, 2);
        p3 = new Property("Prop3", "City3", "Owner3", 1500.0, 1, 1, 2, 2); // overlaps p1
    }

    @Test
    public void testAddPropertySuccess() {
        int index = company.addProperty(p1);
        assertEquals(0, index);
        assertEquals(1, company.getPropertiesCount());
    }

    @Test
    public void testAddPropertyOverlap() {
        company.addProperty(p1);
        int result = company.addProperty(p3);
        assertEquals(-4, result); // overlap
    }

    @Test
    public void testAddPropertyExceedsMax() {
        for (int i = 0; i < 5; i++) {
            company.addProperty(new Property("P" + i, "C", "O", 1000 + i, 0, i, 2, 2));
        }
        int result = company.addProperty(p1);
        assertEquals(-1, result); // array full
    }

    @Test
    public void testAddPropertyNull() {
        int result = company.addProperty((Property)null);
        assertEquals(-2, result);
    }

    @Test
    public void testTotalRentAndHighest() {
        company.addProperty(p1);
        company.addProperty(p2);
        assertEquals(3000.0, company.getTotalRent(), 0.001);
        assertEquals(p2.getRentAmount(), company.getHighestRentPropperty().getRentAmount(), 0.001);
    }

    @Test
    public void testRemoveLastProperty() {
        company.addProperty(p1);
        company.addProperty(p2);
        company.removeLastProperty();
        assertEquals(1, company.getPropertiesCount());
        assertEquals(p1.getPropertyName(), company.getHighestRentPropperty().getPropertyName());
    }

    @Test
    public void testIsPropertiesFull() {
        assertFalse(company.isPropertiesFull());
        for (int i = 0; i < 5; i++)
            company.addProperty(new Property("P" + i, "C", "O", 1000 + i, 0, i, 2, 2));
        assertTrue(company.isPropertiesFull());
    }

    @Test
    public void testManagementFeeValidation() {
        assertTrue(company.isManagementFeeValid());
        ManagementCompany c2 = new ManagementCompany("Co", "TID", -5);
        assertFalse(c2.isManagementFeeValid());
    }

    @Test
    public void testToString() {
        company.addProperty(p1);
        company.addProperty(p2);
        String output = company.toString();
        assertTrue(output.contains("Prop1"));
        assertTrue(output.contains("Prop2"));
        assertTrue(output.contains("total management Fee"));
    }
}
