package assingment4;

/**
 * Class: CMSC203 
 * Instructor: [Your Instructor’s Name]
 * Description: Represents a property with a name, city, rent amount, owner, and plot dimensions.
 * This class supports both constructor orders used in the GUI and test files.
 */

public class Property {
    private String propertyName;
    private String city;
    private double rentAmount;
    private String owner;
    private Plot plot;

    /**
     * Default constructor
     */
    public Property() {
        this("", "", 0.0, "", 0, 0, 1, 1);
    }

    /**
     * Copy constructor
     * @param otherProperty another Property object to copy from
     */
    public Property(Property otherProperty) {
        this(otherProperty.propertyName, otherProperty.city, otherProperty.rentAmount,
             otherProperty.owner, otherProperty.plot.getX(), otherProperty.plot.getY(),
             otherProperty.plot.getWidth(), otherProperty.plot.getDepth());
    }

    /**
     * Constructor used in GUI (order: propertyName, city, rentAmount, owner, x, y, width, depth)
     */
    public Property(String propertyName, String city, double rentAmount, String owner,
                    int x, int y, int width, int depth) {
        this.propertyName = propertyName;
        this.city = city;
        this.rentAmount = rentAmount;
        this.owner = owner;
        this.plot = new Plot(x, y, width, depth);
    }

    /**
     * Constructor used in test class (order: propertyName, city, owner, rentAmount, x, y, width, depth)
     */
    public Property(String propertyName, String city, String owner, double rentAmount,
                    int x, int y, int width, int depth) {
        this.propertyName = propertyName;
        this.city = city;
        this.owner = owner;
        this.rentAmount = rentAmount;
        this.plot = new Plot(x, y, width, depth);
    }

    /**
     * Constructor without plot (defaults to 0,0,1,1)
     */
    public Property(String propertyName, String city, double rentAmount, String owner) {
        this(propertyName, city, rentAmount, owner, 0, 0, 1, 1);
    }

    // ==============================
    // Getters
    // ==============================
    public String getPropertyName() {
        return propertyName;
    }

    public String getCity() {
        return city;
    }

    public double getRentAmount() {
        return rentAmount;
    }

    public String getOwner() {
        return owner;
    }

    public Plot getPlot() {
        return new Plot(plot); // return a copy for safety
    }

   
    // Setters
 
    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setRentAmount(double rentAmount) {
        this.rentAmount = rentAmount;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public void setPlot(int x, int y, int width, int depth) {
        this.plot = new Plot(x, y, width, depth);
    }

    // toString
  
    @Override
    public String toString() {
        return propertyName + "," + city + "," + owner + "," + rentAmount;
    }
}

