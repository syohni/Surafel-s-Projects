package assingment4;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class PlotTestStudent {
    private Plot defaultPlot, customPlot, copyPlot;

    @Before
    public void setUp() {
        defaultPlot = new Plot();
        customPlot = new Plot(2, 3, 5, 6);
        copyPlot = new Plot(customPlot);
    }

    @Test
    public void testDefaultConstructor() {
        assertEquals(0, defaultPlot.getX());
        assertEquals(0, defaultPlot.getY());
        assertEquals(1, defaultPlot.getWidth());
        assertEquals(1, defaultPlot.getDepth());
    }

    @Test
    public void testParameterizedConstructor() {
        assertEquals(2, customPlot.getX());
        assertEquals(3, customPlot.getY());
        assertEquals(5, customPlot.getWidth());
        assertEquals(6, customPlot.getDepth());
    }

    @Test
    public void testCopyConstructor() {
        assertEquals(customPlot.getX(), copyPlot.getX());
        assertEquals(customPlot.getY(), copyPlot.getY());
        assertEquals(customPlot.getWidth(), copyPlot.getWidth());
        assertEquals(customPlot.getDepth(), copyPlot.getDepth());
    }

    @Test
    public void testSettersAndGetters() {
        defaultPlot.setX(10);
        defaultPlot.setY(20);
        defaultPlot.setWidth(30);
        defaultPlot.setDepth(40);

        assertEquals(10, defaultPlot.getX());
        assertEquals(20, defaultPlot.getY());
        assertEquals(30, defaultPlot.getWidth());
        assertEquals(40, defaultPlot.getDepth());
    }

    @Test
    public void testOverlaps() {
        Plot p1 = new Plot(0, 0, 4, 4);
        Plot p2 = new Plot(2, 2, 4, 4);
        Plot p3 = new Plot(5, 5, 2, 2);

        assertTrue(p1.overlaps(p2));
        assertFalse(p1.overlaps(p3));
    }

    @Test
    public void testEncompasses() {
        Plot p1 = new Plot(0, 0, 10, 10);
        Plot p2 = new Plot(2, 2, 5, 5);
        Plot p3 = new Plot(-1, -1, 5, 5);

        assertTrue(p1.encompasses(p2));
        assertFalse(p1.encompasses(p3));
    }

    @Test
    public void testToString() {
        assertEquals("2,3,5,6", customPlot.toString());
    }
}

