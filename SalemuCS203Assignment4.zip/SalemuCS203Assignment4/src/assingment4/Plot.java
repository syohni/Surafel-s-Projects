package assingment4;

public class Plot {
    private int x;
    private int y;
    private int width;
    private int depth;

    // Default constructor
    public Plot() {
        this(0, 0, 1, 1);
    }

    // Parameterized constructor REQUIRED BY TESTS
    public Plot(int x, int y, int width, int depth) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.depth = depth;
    }

    // Copy constructor
    public Plot(Plot otherPlot) {
        this(otherPlot.x, otherPlot.y, otherPlot.width, otherPlot.depth);
    }

    public int getX() { return x; }
    public int getY() { return y; }
    public int getWidth() { return width; }
    public int getDepth() { return depth; }

    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    public void setWidth(int width) { this.width = width; }
    public void setDepth(int depth) { this.depth = depth; }

    // REQUIRED BY TESTS
    public boolean overlaps(Plot plot) {
        if (plot == null) return false;
        return !(plot.x >= this.x + this.width ||
                 plot.x + plot.width <= this.x ||
                 plot.y >= this.y + this.depth ||
                 plot.y + plot.depth <= this.y);
    }

    public boolean encompasses(Plot plot) {
        if (plot == null) return false;
        return (plot.x >= this.x &&
                plot.y >= this.y &&
                plot.x + plot.width <= this.x + this.width &&
                plot.y + plot.depth <= this.y + this.depth);
    }

    @Override
    public String toString() {
        return x + "," + y + "," + width + "," + depth;
    }
}
