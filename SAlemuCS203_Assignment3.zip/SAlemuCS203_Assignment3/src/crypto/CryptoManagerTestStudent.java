package crypto;

/*
 * Class: CMSC203 
 * Instructor: Ahmed Tarek
 * Description: Student JUnit test file for CryptoManager class.
 * Due: 10/14/2025
 * Platform/compiler: Eclipse IDE
 * 
 * I pledge that I have completed the programming assignment independently. 
 * I have not copied the code from a student or any source. 
 * I have not given my code to any student.
 * Print your Name here: Surafel Alemu
 */

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CryptoManagerTestStudent {

    @Before
    public void setUp() throws Exception {
        // Setup code before each test if needed
    }

    @After
    public void tearDown() throws Exception {
        // Cleanup after each test if needed
    }

    // ==============================
    //  Test: isStringInBounds
    // ==============================
    @Test
    public void testIsStringInBounds() {
        assertTrue(CryptoManager.isStringInBounds("HELLO"));
        assertFalse(CryptoManager.isStringInBounds("hello"));  // lowercase not allowed
        assertFalse(CryptoManager.isStringInBounds("{INVALID"));
    }

    // ==============================
    //  Test: Caesar Cipher
    // ==============================
    @Test
    public void testCaesarEncryptionAndDecryption() {
        String plainText = "HELLO WORLD";
        int key = 3;

        String encrypted = CryptoManager.caesarEncryption(plainText, key);
        String decrypted = CryptoManager.caesarDecryption(encrypted, key);

        assertEquals("HELLO WORLD", decrypted);
    }

    // ==============================
    //  Test: Vigenere Cipher
    // ==============================
    @Test
    public void testVigenereEncryptionAndDecryption() {
        String plainText = "ATTACKATDAWN";
        String key = "LEMON";

        String encrypted = CryptoManager.vigenereEncryption(plainText, key);
        String decrypted = CryptoManager.vigenereDecryption(encrypted, key);

        assertEquals("ATTACKATDAWN", decrypted);
    }

    // ==============================
    //  Test: Playfair Cipher
    // ==============================
    @Test
    public void testPlayfairEncryptionAndDecryption() {
        String plainText = "HELLOWORLD";
        String key = "KEYWORD";

        String encrypted = CryptoManager.playfairEncryption(plainText, key);
        String decrypted = CryptoManager.playfairDecryption(encrypted, key);

        assertEquals("HELLOWORLD", decrypted);
    }

    // ==============================
    //  Test: Caesar with invalid input
    // ==============================
    @Test
    public void testCaesarOutOfBounds() {
        String result = CryptoManager.caesarEncryption("hello", 5);
        assertEquals("The selected string is not in bounds, Try again.", result);
    }
}
