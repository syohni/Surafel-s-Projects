import java.util.Scanner;


public class MovieDriver {
	
	 public static void main(String[] args) {
		 
		 Scanner scanner = new Scanner(System.in);
		 String choice;
		 String title;
		 String rating;
		 int ticketsSold ;
		 
		 
		 do {
			
	       Movie myMovie = new Movie();

	      
	       //  information for the movie title
	       System.out.print("Enter the title of the movie: ");
	       title = scanner.nextLine();
	       myMovie.setTitle(title);

	       // information for the movie rating
	       System.out.print("Enter the movie's rating: ");
	       rating = scanner.nextLine();
	       myMovie.setRating(rating);

	       // information for the tickets sold
	       System.out.print("Enter the number of tickets sold: ");
	       ticketsSold = scanner.nextInt();
	       myMovie.setSoldTickets(ticketsSold);

	      
	       scanner.nextLine();

	       // Prints the movie information
	       System.out.println("\nMovie Information:");
	       System.out.println(myMovie.toString());

	       // Asks if the user wants to continue
	       System.out.print("\nDo you want to enter another movie? (yes/no): ");
	       choice = scanner.nextLine().trim().toLowerCase();

	       System.out.println(); 
			 
			 
			 
			 
			 
		 }while (choice.equals("yes"));
		 
		 System.out.println("\nProgrammer: Surafel Alemu");
         
		 scanner.close(); 
	 }

}
