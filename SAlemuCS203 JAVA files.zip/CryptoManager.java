package crypto;
/**
 * CryptoManager.java
 *
 * Implements three simple ciphers (Vigenere, Playfair (8x8), Caesar) with
 * methods required by the assignment. All public methods are static so they
 * can be used by the provided GUI and JUnit tests.
 *
 * Follow assignment requirement: if an input (plain or encrypted or key) is
 * out of allowed ASCII bounds (LOWER_RANGE..UPPER_RANGE), return the exact
 * error message: "The selected string is not in bounds, Try again."
 *
 * Author: Surafel Alemu
 * @version 10/14/2025
 */

public class CryptoManager { 

    private static final char LOWER_RANGE = ' ';
    private static final char UPPER_RANGE = '_';
    private static final int RANGE = UPPER_RANGE - LOWER_RANGE + 1;
    // 64-character alphabet (8x8) for Playfair cipher  
    private static final String ALPHABET64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!\"#$%&'()*+,-./:;<=>?@[\\]^_`";

    /**
     * Check if all characters in input string are within allowed bounds.
     */
    public static boolean isStringInBounds(String plainText) {
        for (int i = 0; i < plainText.length(); i++) {
            if (!(plainText.charAt(i) >= LOWER_RANGE && plainText.charAt(i) <= UPPER_RANGE)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Encrypts using Vigenere cipher.
     */
    public static String vigenereEncryption(String plainText, String key) {
        if (!isStringInBounds(plainText))
            return "The selected string is not in bounds, Try again.";
        StringBuilder encrypted = new StringBuilder();
        for (int i = 0; i < plainText.length(); i++) {
            char p = plainText.charAt(i);
            char k = key.charAt(i % key.length());
            int shifted = ((p - LOWER_RANGE) + (k - LOWER_RANGE)) % RANGE;
            encrypted.append((char) (LOWER_RANGE + shifted));
        }
        return encrypted.toString();
    }

    /**
     * Decrypt Vigenere cipher.
     */
    public static String vigenereDecryption(String encryptedText, String key) {
        if (!isStringInBounds(encryptedText))
            return "The selected string is not in bounds, Try again.";
        StringBuilder decrypted = new StringBuilder();
        for (int i = 0; i < encryptedText.length(); i++) {
            char e = encryptedText.charAt(i);
            char k = key.charAt(i % key.length());
            int shifted = ((e - LOWER_RANGE) - (k - LOWER_RANGE) + RANGE) % RANGE;
            decrypted.append((char) (LOWER_RANGE + shifted));
        }
        return decrypted.toString();
    }

    /**
     * Encrypt plaintext using Playfair cipher with 8x8 matrix.
     * Spaces preserved and left unchanged during encryption.
     */
    public static String playfairEncryption(String plainText, String key) {
        if (!isStringInBounds(plainText))
            return "The selected string is not in bounds, Try again.";
        char[][] matrix = generatePlayfairMatrix(key);
        String txt = formatPlayfairText(plainText);
        StringBuilder encrypted = new StringBuilder();

        // Process text in pairs
        for (int i = 0; i < txt.length(); i += 2) {
            char a = txt.charAt(i);
            char b = txt.charAt(i + 1);

            int[] p1 = findInMatrix(matrix, a);
            int[] p2 = findInMatrix(matrix, b);

            // If either char not found in matrix (like space), append them as is
            if (p1 == null || p2 == null) {
                encrypted.append(a);
                encrypted.append(b);
                continue;
            }

            // Same row: shift right
            if (p1[0] == p2[0]) {
                encrypted.append(matrix[p1[0]][(p1[1] + 1) % 8]);
                encrypted.append(matrix[p2[0]][(p2[1] + 1) % 8]);
            }
            // Same column: shift down
            else if (p1[1] == p2[1]) {
                encrypted.append(matrix[(p1[0] + 1) % 8][p1[1]]);
                encrypted.append(matrix[(p2[0] + 1) % 8][p2[1]]);
            }
            // Rectangle: swap columns
            else {
                encrypted.append(matrix[p1[0]][p2[1]]);
                encrypted.append(matrix[p2[0]][p1[1]]);
            }
        }
        return encrypted.toString();
    }

    /**
     * Decrypt Playfair ciphertext, preserving spaces as is.
     * Removes trailing 'X' padding if present.
     */
    public static String playfairDecryption(String encryptedText, String key) {
        char[][] matrix = generatePlayfairMatrix(key);
        StringBuilder decrypted = new StringBuilder();
        String txt = encryptedText;

        for (int i = 0; i < txt.length(); i += 2) {
            char a = txt.charAt(i);
            char b = txt.charAt(i + 1);

            int[] p1 = findInMatrix(matrix, a);
            int[] p2 = findInMatrix(matrix, b);

            if (p1 == null || p2 == null) {
                decrypted.append(a);
                decrypted.append(b);
                continue;
            }

            // Same row: shift left
            if (p1[0] == p2[0]) {
                decrypted.append(matrix[p1[0]][(p1[1] + 7) % 8]);
                decrypted.append(matrix[p2[0]][(p2[1] + 7) % 8]);
            }
            // Same column: shift up
            else if (p1[1] == p2[1]) {
                decrypted.append(matrix[(p1[0] + 7) % 8][p1[1]]);
                decrypted.append(matrix[(p2[0] + 7) % 8][p2[1]]);
            }
            // Rectangle: swap columns
            else {
                decrypted.append(matrix[p1[0]][p2[1]]);
                decrypted.append(matrix[p2[0]][p1[1]]);
            }
        }

        // Remove trailing 'X' pad if present
        if (decrypted.length() > 0 && decrypted.charAt(decrypted.length() - 1) == 'X') {
            decrypted.deleteCharAt(decrypted.length() - 1);
        }
        return decrypted.toString();
    }

    /**
     * Caesar cipher encryption: shifts characters by key.
     */
    public static String caesarEncryption(String plainText, int key) {
        if (!isStringInBounds(plainText))
            return "The selected string is not in bounds, Try again.";
        StringBuilder encrypted = new StringBuilder();

        for (int i = 0; i < plainText.length(); i++) {
            char c = plainText.charAt(i);
            int shifted = ((c - LOWER_RANGE) + key) % RANGE;
            encrypted.append((char) (LOWER_RANGE + shifted));
        }
        return encrypted.toString();
    }

    /**
     * Caesar cipher decryption: shifts characters by negative key.
     */
    public static String caesarDecryption(String encryptedText, int key) {
        if (!isStringInBounds(encryptedText))
            return "The selected string is not in bounds, Try again.";
        StringBuilder decrypted = new StringBuilder();

        for (int i = 0; i < encryptedText.length(); i++) {
            char c = encryptedText.charAt(i);
            int shifted = ((c - LOWER_RANGE) - key + RANGE) % RANGE;
            decrypted.append((char) (LOWER_RANGE + shifted));
        }
        return decrypted.toString();
    }

    // Helper: generate Playfair matrix with unique chars from key plus remaining chars
    private static char[][] generatePlayfairMatrix(String key) {
        boolean[] used = new boolean[ALPHABET64.length()];
        StringBuilder fullKey = new StringBuilder();

        for (int i = 0; i < key.length(); i++) {
            char c = key.charAt(i);
            int idx = ALPHABET64.indexOf(c);
            if (idx >= 0 && !used[idx]) {
                fullKey.append(c);
                used[idx] = true;
            }
        }

        for (int i = 0; i < ALPHABET64.length(); i++) {
            if (!used[i]) fullKey.append(ALPHABET64.charAt(i));
        }

        char[][] matrix = new char[8][8];
        for (int i = 0; i < 64; i++)
            matrix[i / 8][i % 8] = fullKey.charAt(i);

        return matrix;
    }

    // Helper: find position of char in Playfair matrix (returns null if not found)
    private static int[] findInMatrix(char[][] matrix, char c) {
        for (int r = 0; r < 8; r++)
            for (int col = 0; col < 8; col++)
                if (matrix[r][col] == c)
                    return new int[]{r, col};
        return null;
    }

    // Helper: prepare text for Playfair by leaving spaces, padding with 'X' if odd length
    private static String formatPlayfairText(String txt) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < txt.length(); i++) {
            sb.append(txt.charAt(i)); // Keep spaces as is
        }
        if (sb.length() % 2 == 1) sb.append('X');
        return sb.toString();
    }
}

        