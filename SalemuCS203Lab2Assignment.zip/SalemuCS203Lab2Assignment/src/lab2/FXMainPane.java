package lab2;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class FXMainPane extends VBox {

	// Task #2: five buttons, label, textfield, two HBoxes
	private Button helloBtn, howdyBtn, chineseBtn, clearBtn, exitBtn, spanishBtn; // spanishBtn optional
	private Label feedbackLbl;
	private TextField feedbackTf;
	private HBox buttonBox, feedbackBox;

	// Task #4: DataManager instance
	private DataManager dataManager;

	FXMainPane() {

		// Task #4: instantiate DataManager
		dataManager = new DataManager();

		// Task #2: instantiate controls
		helloBtn = new Button("Hello");
		howdyBtn = new Button("Howdy");
		chineseBtn = new Button("Chinese");
		clearBtn = new Button("Clear");
		exitBtn = new Button("Exit");

		// OPTIONAL “fun” button
		spanishBtn = new Button("Spanish");

		feedbackLbl = new Label("Feedback:");
		feedbackTf = new TextField();
		feedbackTf.setEditable(false);

		// Task #2: instantiate HBoxes
		buttonBox = new HBox();
		feedbackBox = new HBox();

		// Task #3: add components into HBoxes
		buttonBox.getChildren().addAll(helloBtn, howdyBtn, chineseBtn, spanishBtn, clearBtn, exitBtn);
		feedbackBox.getChildren().addAll(feedbackLbl, feedbackTf);

		// Task #3: add HBoxes into VBox (this)
		getChildren().addAll(buttonBox, feedbackBox);

		// Task #4: make buttons respond to clicks
		ButtonHandler handler = new ButtonHandler();
		helloBtn.setOnAction(handler);
		howdyBtn.setOnAction(handler);
		chineseBtn.setOnAction(handler);
		spanishBtn.setOnAction(handler); // optional
		clearBtn.setOnAction(handler);
		exitBtn.setOnAction(handler);

		// Task #4: spacing + centering
		buttonBox.setAlignment(Pos.CENTER);
		feedbackBox.setAlignment(Pos.CENTER);

		Insets inset = new Insets(10);

		HBox.setMargin(helloBtn, inset);
		HBox.setMargin(howdyBtn, inset);
		HBox.setMargin(chineseBtn, inset);
		HBox.setMargin(spanishBtn, inset); // optional
		HBox.setMargin(clearBtn, inset);
		HBox.setMargin(exitBtn, inset);

		HBox.setMargin(feedbackLbl, inset);
		HBox.setMargin(feedbackTf, inset);

		setAlignment(Pos.CENTER);
		setPadding(new Insets(15));
		setSpacing(10);
	}

	// Task #4: private inner class handler
	private class ButtonHandler implements EventHandler<ActionEvent> {

		@Override
		public void handle(ActionEvent event) {
			Object source = event.getTarget();

			if (source == helloBtn) {
				feedbackTf.setText(dataManager.getHello());
			} else if (source == howdyBtn) {
				feedbackTf.setText(dataManager.getHowdy());
			} else if (source == chineseBtn) {
				feedbackTf.setText(dataManager.getChinese());
			} else if (source == spanishBtn) { // optional
				feedbackTf.setText(dataManager.getSpanish());
			} else if (source == clearBtn) {
				feedbackTf.setText("");
			} else if (source == exitBtn) {
				Platform.exit();
				System.exit(0);
			}
		}
	}
}
