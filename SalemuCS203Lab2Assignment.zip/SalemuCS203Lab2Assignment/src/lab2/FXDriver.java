package lab2;

import java.io.IOException;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class FXDriver extends Application {

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage stage) throws IOException {
		// Task #1: instantiate FXMainPane and set it in the Scene
		FXMainPane root = new FXMainPane();
		Scene scene = new Scene(root, 500, 200);

		stage.setTitle("Hello World GUI");
		stage.setScene(scene);
		stage.show();
	}
}
