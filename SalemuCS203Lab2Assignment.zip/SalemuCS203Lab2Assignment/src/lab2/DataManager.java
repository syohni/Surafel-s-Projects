package lab2;

public class DataManager {

	DataManager() { }

	public String getHello() {
		return "Hello World";
	}

	public String getHowdy() {
		return "Howdy y'all";
	}

	public String getChinese() {
		return "Ni hau";
	}

	// OPTIONAL Task #4 (fun): extra language
	public String getSpanish() {
		return "Hola";
	}
}

