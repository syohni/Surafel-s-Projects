import java.text.DecimalFormat;

public class Procedure {
	private String procedureName;
	private String procedureDate;
	private String practitionerName;
	private double charges;
	
	public Procedure() {
	    procedureName = "";
	    procedureDate = "";
	    practitionerName = "";
	    charges = 0.0;
	}

	public Procedure(String procedureName, String procedureDate) {
	    this.procedureName = procedureName;
	    this.procedureDate = procedureDate;
	    practitionerName = "";
	    charges = 0.0;
	}
	
	public Procedure(String procedureName, String procedureDate, String practitionerName, double charges) {
		setProcedureName(procedureName);
		setProcedureDate(procedureDate);
		setPractitionerName(practitionerName);
		setCharges(charges);
	}
	
	public void setProcedureName(String procedureName) 
	{ 
		this.procedureName = procedureName; 
		
	}
    
	public void setProcedureDate(String procedureDate) 
    { 
    	this.procedureDate = procedureDate; 
    	
    }
    
	public void setPractitionerName(String practitionerName) 
    { 
    	this.practitionerName = practitionerName; 
    	
    }
    
    public void setCharges(double charges) 
    {
    	this.charges = charges; 
    	
    }
    
    public String getProcedureName() 
    { 
    	return procedureName; 
    	
    }
   
    public String getProcedureDate() 
    { 
    	return procedureDate; 
    	
    }
   
    public String getPractitionerName() 
    { 
    	return practitionerName;
    	
    }
    
    public double getCharges() 
    { 
    	return charges; 
    	
    }
    
    public String toString() 
    {
    	DecimalFormat df = new DecimalFormat("0.00"); // always 2 decimal places
    	String formatted = df.format(charges);
        return "Procedure Name: " + getProcedureName() + "\nDate: " + getProcedureDate() + "\nPractitioner: " + getPractitionerName() +  "\nCharges: $" + formatted; // tells the decimal number to 2 digit after the decimal point
    }
}
