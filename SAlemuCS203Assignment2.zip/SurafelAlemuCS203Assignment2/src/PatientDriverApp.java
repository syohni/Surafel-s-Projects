import java.util.Scanner;
import java.text.DecimalFormat;

/*
 * Class: CMSC203 
 * Instructor: Ahmed Tarek
 * Description: (Give a brief description for each Class)
 * Due: 09/30/2025
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Surafel Alemu_______
*/

public class PatientDriverApp {

    // Method to display patient info
    public void displayPatient(Patient patient) {
        System.out.println(patient.toString());
    }

    // Method to display procedure info
    public void displayProcedure(Procedure procedure) {
        System.out.println(procedure.toString());
    }

    // Method to calculate total charges of three procedures
    public double calculateTotalCharges(Procedure p1, Procedure p2, Procedure p3) {
        return p1.getCharges() + p2.getCharges() + p3.getCharges();
    }


	
	public static void main(String[] arg) {
		
		// patient's Descriptive information
		String firstName;
		String middleName;
		String lastName;
        String streetAddress;
		String city;
		String state;
		String zip;
        String phoneNumber;
        String emergencyName;
		String emergencyPhone;
        
		Scanner scanner = new Scanner(System.in);
		DecimalFormat df = new DecimalFormat("0.00"); // used this to limit it to two decimal point
		PatientDriverApp app = new PatientDriverApp(); // i used it to display the class objects 
		
		// Patient object
		Patient patient = null;

		// procedure 1 information
		String proc1Name;
		String proc1Date;
		String proc1Practitioner;
		double proc1Charges;
		Procedure proc1 = null;

		// procedure 2 information
		String proc2Name;
		String proc2Date;
		String proc2Practitioner;
		double proc2Charges;
		Procedure proc2 = null;

		// procedure 3 information
		String proc3Name;
		String proc3Date;
		String proc3Practitioner;
		double proc3Charges;
		Procedure proc3 = null;
		
		double totalCharges; // shows the total charges of the procedures
		
		int choice;
		
		// Program Header
        System.out.println("Class: CMSC203 CRN XXXX");
        System.out.println("Program: Assignment 2");
        System.out.println("Instructor: Ahmed Tarek");
        System.out.println("Student’s Name: Surafel Alemu");
        System.out.println("-----------------------------------\n");
		
        
		
		do {
		    // Display menu
		    System.out.println("\nMenu:");
		    System.out.println("1. Add Patient");
		    System.out.println("2. Add Procedure 1");
		    System.out.println("3. Add Procedure 2");
		    System.out.println("4. Add Procedure 3");
		    System.out.println("5. Display Patient Info");
		    System.out.println("6. Display Procedures");
		    System.out.println("7. Calculate Total Charges");
		    System.out.println("0. Exit");

		    System.out.print("Enter choice: ");
		    choice = scanner.nextInt();
		    scanner.nextLine(); // consume newline

		    switch (choice) {
		        case 1:
		            System.out.println("Enter patient information:");

		            System.out.print("First Name: ");
		            firstName = scanner.nextLine();

		            System.out.print("Middle Name: ");
		            middleName = scanner.nextLine();

		            System.out.print("Last Name: ");
		            lastName = scanner.nextLine();

		            System.out.print("Street Address: ");
		            streetAddress = scanner.nextLine();

		            System.out.print("City: ");
		            city = scanner.nextLine();

		            System.out.print("State: ");
		            state = scanner.nextLine();

		            System.out.print("ZIP Code: ");
		            zip = scanner.nextLine();

		            System.out.print("Phone Number: ");
		            phoneNumber = scanner.nextLine();

		            System.out.print("Emergency Contact Name: ");
		            emergencyName = scanner.nextLine();

		            System.out.print("Emergency Contact Phone: ");
		            emergencyPhone = scanner.nextLine();

		            patient = new Patient(firstName, middleName, lastName, streetAddress, city, state, zip, phoneNumber, emergencyName, emergencyPhone);

		            System.out.println("\n--- Patient Information ---");
		            break;

		        case 2:
		            // Add procedure 1
		            System.out.print("Procedure 1 Name: ");
		            proc1Name = scanner.nextLine();

		            System.out.print("Date: ");
		            proc1Date = scanner.nextLine();

		            System.out.print("Practitioner: ");
		            proc1Practitioner = scanner.nextLine();

		            System.out.print("Charges: ");
		            proc1Charges = scanner.nextDouble();
		            scanner.nextLine();

		            proc1 = new Procedure(proc1Name, proc1Date, proc1Practitioner, proc1Charges);

		            System.out.println("Procedure 1 added!");
		            break;

		        case 3:
		            // Add Procedure 2
		            System.out.print("Procedure 2 Name: ");
		            proc2Name = scanner.nextLine();

		            System.out.print("Date: ");
		            proc2Date = scanner.nextLine();

		            System.out.print("Practitioner: ");
		            proc2Practitioner = scanner.nextLine();

		            System.out.print("Charges: ");
		            proc2Charges = scanner.nextDouble();
		            scanner.nextLine();

		            proc2 = new Procedure(proc2Name, proc2Date, proc2Practitioner, proc2Charges);

		            System.out.println("Procedure 2 added!");
		            break;

		        case 4:
		            // Add Procedure 3
		            System.out.print("Procedure 3 Name: ");
		            proc3Name = scanner.nextLine();

		            System.out.print("Date: ");
		            proc3Date = scanner.nextLine();

		            System.out.print("Practitioner: ");
		            proc3Practitioner = scanner.nextLine();

		            System.out.print("Charges: ");
		            proc3Charges = scanner.nextDouble();
		            scanner.nextLine();

		            proc3 = new Procedure(proc3Name, proc3Date, proc3Practitioner, proc3Charges);

		            System.out.println("Procedure 3 added!");
		            break;

		        case 5:
		            if (patient != null) {
		                app.displayPatient(patient);
		            } else {
		                System.out.println("No patient added yet.");
		            }
		            break;

		        case 6:
		        	if (proc1 != null) {
		        		app.displayProcedure(proc1);
		        	}
		        	
		        	 if (proc2 != null) {
		        		app.displayProcedure(proc2);
		        	}
		        	
		            
		        	 if (proc3 != null) {
		            	app.displayProcedure(proc3);
		            }
		            
		            break;

		        case 7:
		        	// display total charge
		        	
		        	if (proc1 != null && proc2 != null && proc3 != null) 
		        	{
		                totalCharges = app.calculateTotalCharges(proc1, proc2, proc3);
		                System.out.println("Total Charges: $" + df.format(totalCharges));
		            } 
		        	
		        	else {
		                System.out.println("Not all procedures are added yet.");
		            }
		            
		            break;

		        case 0:
		        	// exit program
		            System.out.println("Exiting program...");
		            break;

		        default:
		            System.out.println("Invalid choice. Please try again.");
		    }

		} while (choice != 0);
		
		
		System.out.println("\nProgrammer: Surafel Alemu");
		scanner.close();
	
}
}       	
        
        
	
