
public class Patient {
	private String firstName;
	private String middleName;
	private String lastName;
	private String streetAddress;
	private String city;
	private String state;
	private String zip;
	private String phoneNumber;
	private String emergencyContactName;
	private String emergencyContactPhone;
	
	public Patient() {
		
	}
	
	// this sets the first, middle and last name of the patient 
	public Patient(String firstName, String middleName, String lastName) {
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
    }
	
	// this returns patient value of the and calls patient() to sent the names  
	public Patient createPatient(String firstName, String middleName, String lastName) {
	    Patient newPatient = new Patient(firstName, middleName, lastName); 
	    return newPatient;
	}
	
	// gets the first name
	public String getFirstName() {
        return firstName;
    }
	//gets the middle name
    public String getMiddleName() {
        return middleName;
    }
    // gets the last name
    public String getLastName() {
        return lastName;
    }
    // gets the string address
    public String getStreetAddress() {
        return streetAddress;
    }
    //gets the city
    public String getCity() {
        return city;
    }
    // gets the state
    public String getState() {
        return state;
    }
    // gets the area code
    public String getZip() {
        return zip;
    }
    // gets the phone number 
    public String getPhoneNumber() {
        return phoneNumber;
    }
    // gets the emergency contact name
    public String getEmergencyContactName() {
        return emergencyContactName;
    }
    // gets the emergency contact number 
    public String getEmergencyContactPhone() {
        return emergencyContactPhone;
    }

    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public void setState(String state) {
        this.state = state;
    }
    public void setZip(String zip) {
        this.zip = zip;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public void setEmergencyContactName(String emergencyContactName) {
        this.emergencyContactName = emergencyContactName;
    }
    public void setEmergencyContactPhone(String emergencyContactPhone) {
        this.emergencyContactPhone = emergencyContactPhone;
    }

   
    public String buildFullName() {
        return firstName + " " + middleName + " " + lastName;
    }

    public String buildAddress() {
        return streetAddress + " " + city + " " + state + " " + zip;
    }

    public String buildEmergencyContact() {
        return emergencyContactName + " " + emergencyContactPhone;
    }
    
    // sets the whole patients information
    public Patient(String firstName, String middleName, String lastName, String streetAddress, String city, String state, String zip, String phoneNumber, String emergencyContactName, String emergencyContactPhone) 
    {
 
 
       setFirstName(firstName);
       setMiddleName(middleName);
       setLastName(lastName);
       setStreetAddress(streetAddress);
       setCity(city);
       setState(state);
       setZip(zip);
       setPhoneNumber(phoneNumber);
       setEmergencyContactName(emergencyContactName);
       setEmergencyContactPhone(emergencyContactPhone);
}

    // returns the whole patient information
    public String toString() {
        return "Patient Information:\n" + "Name: " + buildFullName() + "\n" +  "Address: " + buildAddress() + "\n" +  "Phone: " + getPhoneNumber() + "\n" + "Emergency Contact: " + buildEmergencyContact();
    }
}

