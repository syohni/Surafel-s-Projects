/**
 *
 */
/**
 *
 */
module SalemuCS203Assignment6{
    requires org.junit.jupiter.api;
    opens Assignment6 to org.junit.platform.commons;

}
