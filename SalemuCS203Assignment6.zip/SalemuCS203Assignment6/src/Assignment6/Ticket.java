package Assignment6;

public class Ticket {
    private double basePrice;
    private String dayOfWeek;
    private int age;

    public Ticket(String dayOfWeek, double basePrice, int age) {
        this.basePrice = basePrice;
        this.age = age;
        this.dayOfWeek = dayOfWeek.toLowerCase();
    }

    // Calculate ticket price based on day of week and age
    // Apply discounts for weekdays (DayOfWeek enum)
    // Apply age-based discounts (child/student/senior)
    public double calculatePrice() {
        double price = basePrice;

        // Day discount
        try {
            DayOfWeek day = DayOfWeek.valueOf(dayOfWeek.toUpperCase());
            price = price * (1.0 - day.getDiscount());
        } catch (IllegalArgumentException e) {
            // If dayOfWeek is invalid, ignore day discount
        }

        // Age-based discounts:
        // child (under 12): 10%
        // student/young (12-25): 10%
        // senior (65+): 5%
        double ageDiscount = 0.0;
        if (age < 12) {
            ageDiscount = 0.10;
        } else if (age <= 25) {
            ageDiscount = 0.10;
        } else if (age >= 65) {
            ageDiscount = 0.05;
        }

        price = price * (1.0 - ageDiscount);
        return price;
    }

    // Display the ticket details
    public void displayTicketDetails() {
        System.out.printf(
                "Ticket Details: [Age: %d, Day: %s, Price: $%.2f]%n",
                age,
                dayOfWeek.substring(0, 1).toUpperCase() + dayOfWeek.substring(1),
                calculatePrice()
        );
    }

    @Override
    public String toString() {
        return String.format(
                "Ticket [Day: %s, Age: %d, Price: $%.2f]",
                dayOfWeek.substring(0, 1).toUpperCase() + dayOfWeek.substring(1),
                age,
                calculatePrice()
        );
    }
}
