package Assignment6;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CircusDriverAppJUnitstudentTest {
    private Circus circus;

    @BeforeEach
    void setUp() {
        circus = new Circus();
    }

    @Test
    void testAddDog() {
        Dog dog = new Dog("Shila", 3, "Golden Retriever", "Brown");
        circus.addAnimal(dog);
        List<Animal> animals = circus.getAnimals();
        assertEquals(1, animals.size());
        assertTrue(animals.get(0) instanceof Dog);
        assertEquals("Shila", animals.get(0).getName());
    }

    @Test
    void testAddBird() {
        Bird bird = new Bird("Tweety", 2, "Canary", "Yellow");
        circus.addAnimal(bird);
        List<Animal> animals = circus.getAnimals();
        assertEquals(1, animals.size());
        assertTrue(animals.get(0) instanceof Bird);
        assertEquals("Tweety", animals.get(0).getName());
    }

    @Test
    void testDisplayAnimals() {
        circus.addAnimal(new Dog("Dog1", 3, "Breed1", "Black"));
        circus.addAnimal(new Bird("Bird1", 1, "Species1", "Blue"));
        // Just ensure it does not throw
        assertDoesNotThrow(() -> circus.displayAllAnimals());
    }

    @Test
    void testSortAnimalsByAge() {
        circus.addAnimal(new Dog("Old", 10, "Breed1", "Black"));
        circus.addAnimal(new Dog("Young", 2, "Breed2", "White"));
        circus.addAnimal(new Dog("Middle", 5, "Breed3", "Gray"));

        circus.sortAnimalsByAge();

        List<Animal> animals = circus.getAnimals();
        assertEquals("Young", animals.get(0).getName());
        assertEquals("Middle", animals.get(1).getName());
        assertEquals("Old", animals.get(2).getName());
    }

    @Test
    void testSortAnimalsByName() {
        circus.addAnimal(new Dog("Charlie", 4, "Breed1", "Black"));
        circus.addAnimal(new Dog("Bella", 3, "Breed2", "Brown"));
        circus.addAnimal(new Dog("Alex", 2, "Breed3", "White"));

        circus.sortAnimalsByName();
        List<Animal> animals = circus.getAnimals();

        assertEquals("Alex", animals.get(0).getName());
        assertEquals("Bella", animals.get(1).getName());
        assertEquals("Charlie", animals.get(2).getName());
    }

    @Test
    void testSearchAnimalByName() {
        Dog dog = new Dog("Buddy", 5, "Labrador", "Brown");
        circus.addAnimal(dog);

        Animal found = circus.searchAnimalByName("Buddy");
        assertNotNull(found);
        assertEquals("Buddy", found.getName());

        Animal notFound = circus.searchAnimalByName("Ghost");
        assertNull(notFound);
    }

    @Test
    void testAddAndDisplayTickets() {
        Ticket t1 = circus.generateTicket("monday", 20.0, 10);
        Ticket t2 = circus.generateTicket("saturday", 20.0, 30);

        List<Ticket> tickets = circus.getTickets();
        assertEquals(2, tickets.size());
        assertEquals(t1, tickets.get(0));
        assertEquals(t2, tickets.get(1));

        assertDoesNotThrow(() -> circus.displayAllTickets());
    }
}

