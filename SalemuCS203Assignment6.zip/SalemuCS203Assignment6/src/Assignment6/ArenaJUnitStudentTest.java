package Assignment6;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ArenaJUnitStudentTest {

    private Arena arena;

    @BeforeEach
    void setUp() {
        arena = new Arena("Blue", 100.0, 50.0);
    }

    @Test
    void testConstructorAndInitialValues() {
        assertEquals("Blue", arena.getColor(), "Initial color is incorrect.");
        assertEquals(100.0, arena.getLength(), 0.001, "Initial length is incorrect.");
        assertEquals(50.0, arena.getWidth(), 0.001, "Initial width is incorrect.");
        assertEquals("Arena", arena.getBuildingType(), "Initial building type is incorrect.");
    }

    @Test
    void testSetSize() {
        arena.setSize(120.0, 60.0);
        assertEquals(120.0, arena.getLength(), 0.001);
        assertEquals(60.0, arena.getWidth(), 0.001);
    }

    @Test
    void testSetColor() {
        arena.setColor("Red");
        assertEquals("Red", arena.getColor());
    }

    @Test
    void testSetBuildingType() {
        arena.setBuildingType("Show Arena");
        assertEquals("Show Arena", arena.getBuildingType());
    }

    @Test
    void testToString() {
        String s = arena.toString();
        assertTrue(s.contains("Blue"));
        assertTrue(s.contains("100.0"));
        assertTrue(s.contains("50.0"));
        assertTrue(s.contains("Arena"));
    }
}

