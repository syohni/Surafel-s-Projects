package Assignment6;

import java.util.Objects;

public class Lion implements Animal {
    //instance variables
    private String name;
    private int age;
    private String species;
    private String color;

    //constructor
    public Lion(String name, int age, String species, String color) {
        this.name = name;
        this.age = age;
        this.species = species;
        this.color = color;
    }

    @Override
    public void move() {
        System.out.println(name + " is prowling.");
    }

    @Override
    public void makeSound() {
        System.out.println(name + " roars loudly.");
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getAge() {
        return age;
    }

    @Override
    public boolean equals(Object o) {
        // Check for reference equality
        if (this == o) {
			return true;
		}
        // Check for null or different class
        if (o == null || getClass() != o.getClass()) {
			return false;
		}
        Lion lion = (Lion) o;
        // Compare fields for logical equality
        return age == lion.age &&
                Objects.equals(name, lion.name) &&
                Objects.equals(species, lion.species) &&
                Objects.equals(color, lion.color);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, age, species, color);
    }

    @Override
    public String toString() {
        return "Lion{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", species='" + species + '\'' +
                ", color='" + color + '\'' +
                '}';
    }
}

