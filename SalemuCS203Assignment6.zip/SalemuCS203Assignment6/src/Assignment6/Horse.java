package Assignment6;

import java.util.Objects;

public class Horse implements Animal {

    //instance variables
    private String name;
    private int age;
    private String species;
    private String color;

    //constructor
    public Horse(String name, int age, String species, String color) {
        this.name = name;
        this.age = age;
        this.species = species;
        this.color = color;
    }

    @Override
    public void move() {
        System.out.println(name + " is galloping.");
    }

    @Override
    public void makeSound() {
        System.out.println(name + " neighs.");
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getAge() {
        return age;
    }

    @Override
    public boolean equals(Object o) {
        // Check for reference equality
        if (this == o) {
			return true;
		}
        // Check for null or different class
        if (o == null || getClass() != o.getClass()) {
			return false;
		}
        Horse horse = (Horse) o;
        // Compare fields for logical equality
        return age == horse.age &&
                Objects.equals(name, horse.name) &&
                Objects.equals(species, horse.species) &&
                Objects.equals(color, horse.color);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, age, species, color);
    }

    @Override
    public String toString() {
        return "Horse{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", species='" + species + '\'' +
                ", color='" + color + '\'' +
                '}';
    }
}

