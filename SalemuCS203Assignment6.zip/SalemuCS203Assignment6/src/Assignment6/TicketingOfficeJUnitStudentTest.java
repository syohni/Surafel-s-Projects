package Assignment6;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TicketingOfficeJUnitStudentTest {

    private TicketingOffice office;

    @BeforeEach
    void setUp() {
        office = new TicketingOffice("Green", 30.0, 20.0);
    }

    @Test
    void testConstructor() {
        assertEquals("Green", office.getColor());
        assertEquals(30.0, office.getLength(), 0.001);
        assertEquals(20.0, office.getWidth(), 0.001);
        assertEquals("Ticketing Office", office.getBuildingType());
    }

    @Test
    void testSetSize() {
        office.setSize(50.0, 40.0);
        assertEquals(50.0, office.getLength(), 0.001);
        assertEquals(40.0, office.getWidth(), 0.001);
    }

    @Test
    void testSetColor() {
        office.setColor("Yellow");
        assertEquals("Yellow", office.getColor());
    }

    @Test
    void testSetBuildingType() {
        office.setBuildingType("VIP Ticket Office");
        assertEquals("VIP Ticket Office", office.getBuildingType());
    }

    @Test
    void testToString() {
        String s = office.toString();
        assertTrue(s.contains("Green"));
        assertTrue(s.contains("30.0"));
        assertTrue(s.contains("20.0"));
        assertTrue(s.contains("Ticketing Office"));
    }
}

