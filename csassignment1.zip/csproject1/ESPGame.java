import java.util.Random;
import java.util.Scanner;

public class ESPGame {
    public static void main(String[] args) {
        // Program Header
        System.out.println("Class: CMSC203 CRN XXXX");
        System.out.println("Program: Assignment 1");
        System.out.println("Instructor: Ahmed Tarek");
        System.out.println("Student’s Name: Surafel Alemu");
        System.out.println("-----------------------------------\n");

        Scanner input = new Scanner(System.in);
        Random rand = new Random();

        // Prompt to input the name
        System.out.print("Enter your name: ");
        String name = input.nextLine();

        // Prompt to input the players description
        System.out.print("Describe yourself: ");
        String description = input.nextLine();

        //  Initialize counter
        int correctGuesses = 0;

        //  Repeat 10 rounds to guess the correct colour
        for (int round = 1; round <= 10; round++) {
            // Randomly choose one color 
            int randomNumber = rand.nextInt(5); 
            String computerColor = "";
           
            switch (randomNumber) {
            case 0: 
            	computerColor = "Red";
            	break;
            
            case 1: 
            	computerColor = "Green";
            	break;
            
            case 2: 
            	computerColor = "Blue"; 
            	break;
           
            case 3:
            	computerColor = "Orange"; 
            	break;
           
            case 4: 
            	computerColor = "Yellow";
            	break;
        }

            // Displays  message
            System.out.println("\nRound " + round + ": I am thinking of a color.");

            //  Ask user and validate input
            String guess = "";
            boolean valid = false;
            while (!valid) {
                System.out.print("Enter your guess (Red, Green, Blue, Orange, Yellow): ");
                guess = input.nextLine();
                
                
                if (guess.equals("Red") || guess.equals("Green") || guess.equals("Blue") || guess.equals("Orange") || guess.equals("Yellow")) 
               
                {
                	    valid = true;
                	
                } else {
                	    System.out.println("Invalid input. Please try again.");
                	}
            }

            // Compare guesses
            if (guess.equals(computerColor)) {
                correctGuesses++;
                System.out.println("Correct!");
            } else {
                System.out.println("Wrong!");
            }

            // Show computer’s choice
            System.out.println("I was thinking of: " + computerColor);
        }

        // After 10 rounds
        System.out.println("\n------- Game Over ---------");
        System.out.println("You guessed correctly " + correctGuesses + " times.");
        System.out.println("Player: " + name);
        System.out.println("About: " + description);

        // Programmer’s name
        System.out.println("\nProgrammer: Surafel Alemu");

        // End program
        input.close();
    }
}

